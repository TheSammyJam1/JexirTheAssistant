import webbrowser


def feedback():
    webbrowser.open('https://discord.gg/xMZwRjSWWv')
    print('Thank You for Leaving Feedback!')