from functions.options import canthelpmeo, jokeo, matho, webo, feedbacko, domylaundryo, updatejexo, jwikio, getwatero, quito


def commands():
    # All The Commands
    print('Command List(0):')
    print(' - Can`t help me = '+canthelpmeo)
    print(' - Quit = '+quito+'\n - Get me water = ' + getwatero)
    print(' - Tell me a joke = '+ jokeo)
    print(' - Math = '+ matho)
    print(' - Open Website = '+ webo)
    print(' - Leave Feedback = ' + feedbacko)
    print(' - Do My laundry! = '+ domylaundryo)
    print(' - Update Jexir = ' + updatejexo)
    print(' - Jexir Wiki = '+ jwikio)
    print('How may I help You?')
